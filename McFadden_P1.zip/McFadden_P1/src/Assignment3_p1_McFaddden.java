import java.security.SecureRandom;
import java.util.Scanner;

class Assignment3_p1_McFadden{

   /*
    public static int level(int level, int random){
        int x = 0;
        x =  random % (math.pow(10, level));
        return x;
    }
    */
   public static  void main(String[] args){
       work(args);
   }

    private static void work(String[] args){
        SecureRandom random = new SecureRandom();
        Scanner sn = new Scanner(System.in);

        int arithmetic, level, i, response;
        double a, x, y, results, c = 0, z;


        System.out.println("Input arithmetic type");
        System.out.println("1 = Addition");
        System.out.println("2 = Multiplication");
        System.out.println("3 = Subtraction");
        System.out.println("4 = Division");
        System.out.println("5 = Random Choice of 1-4");
        arithmetic = sn.nextInt();

        System.out.println("Input level of difficulty 1 through 4!");
        level = sn.nextInt();

        if (arithmetic == 5) {
            for (i = 0; i < 10; i++) {
                arithmetic = random.nextInt(4) + 1;
                if (arithmetic == 1) {
                    if (level == 1) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10);
                            y = random.nextInt(10);

                            System.out.println("How much is " + x + " plus " + y + "?");
                            z = x + y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }
                                //}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");

                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 2) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(100);
                            y = random.nextInt(100);

                            System.out.println("How much is " + x + " plus " + y + "?");
                            z = x + y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;

                                }   //}

                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 3) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(1000);
                            y = random.nextInt(1000);

                            System.out.println("How much is " + x + " plus " + y + "?");
                            z = x + y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }//}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 4) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10000);
                            y = random.nextInt(10000);

                            System.out.println("How much is " + x + " plus " + y + "?");
                            z = x + y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                    //}
                                }
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }

                            }

                            results = c / 10;
                            System.out.println(results);
                            if (results < .75) {
                                System.out.println("Please ask your teacher for extra help.");
                            } else {
                                System.out.println("Congratulations, you are ready to go to the next level!");
                            }
                            // Recursively calls main for a reset!
                            work(args);
                        }
                    }
                } else if (arithmetic == 2) {
                    if (level == 1) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10);
                            y = random.nextInt(10);

                            System.out.println("How much is " + x + " times " + y + "?");
                            z = x * y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }
                                //}
                            }
                            else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");

                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 2) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(100);
                            y = random.nextInt(100);

                            System.out.println("How much is " + x + " times " + y + "?");
                            z = x * y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;

                                }   //}

                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 3) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(1000);
                            y = random.nextInt(1000);

                            System.out.println("How much is " + x + " times " + y + "?");
                            z = x * y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }//}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 4) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10000);
                            y = random.nextInt(10000);

                            System.out.println("How much is " + x + " times " + y + "?");
                            z = x * y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                    //}
                                }
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }

                            }

                            results = c / 10;
                            System.out.println(results);
                            if (results < .75) {
                                System.out.println("Please ask your teacher for extra help.");
                            } else {
                                System.out.println("Congratulations, you are ready to go to the next level!");
                            }
                            // Recursively calls main for a reset!
                            work(args);
                        }

                    }
                } else if (arithmetic == 3) {
                    if (level == 1) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10);
                            y = random.nextInt(10);

                            System.out.println("How much is " + x + " minus " + y + "?");
                            z = x - y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }
                                //}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");

                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 2) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(100);
                            y = random.nextInt(100);

                            System.out.println("How much is " + x + " minus " + y + "?");
                            z = x - y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;

                                }   //}

                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 3) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(1000);
                            y = random.nextInt(1000);

                            System.out.println("How much is " + x + " minus " + y + "?");
                            z = x - y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }//}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                       work(args);
                    } else if (level == 4) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10000);
                            y = random.nextInt(10000);

                            System.out.println("How much is " + x + " minus " + y + "?");
                            z = x - y;
                            a = sn.nextInt();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                    //}
                                }
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }

                            }

                            results = c / 10;
                            System.out.println(results);
                            if (results < .75) {
                                System.out.println("Please ask your teacher for extra help.");
                            } else {
                                System.out.println("Congratulations, you are ready to go to the next level!");
                            }
                            // Recursively calls main for a reset!
                            work(args);
                        }

                    }
                } else if (arithmetic == 4) {
                    if (level == 1) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10);
                            y = random.nextInt(10);

                            System.out.println("How much is " + x + " divided by " + y + "?");
                            z = x / y;
                            a = sn.nextDouble();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }
                                //}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 2) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(100);
                            y = random.nextInt(100);

                            System.out.println("How much is " + x + " divided by " + y + "?");
                            z = x / y;
                            a = sn.nextDouble();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;

                                }   //}

                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 3) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(1000);
                            y = random.nextInt(1000);

                            System.out.println("How much is " + x + " divided by " + y + "?");
                            z = x / y;
                            a = sn.nextDouble();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                }//}
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;

                                }
                            }
                        }

                        results = c / 10;
                        System.out.println(results);
                        if (results < .75) {
                            System.out.println("Please ask your teacher for extra help.");
                        } else {
                            System.out.println("Congratulations, you are ready to go to the next level!");
                        }
                        // Recursively calls main for a reset!
                        work(args);
                    } else if (level == 4) {
                        for (i = 0; i < 10; i++) {
                            x = random.nextInt(10000);
                            y = random.nextInt(10000);

                            System.out.println("How much is " + x + " divided by " + y + "?");
                            z = x / y;
                            a = sn.nextDouble();
                            if (a != z) {
                                // While(a != z) removed for part 3!
                                //{
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("No. Please try again.");
                                        break;
                                    case 1:
                                        System.out.println("Wrong. Please try again.");
                                        break;
                                    case 2:
                                        System.out.println("Don't give up!");
                                        break;
                                    case 3:
                                        System.out.println("No. Keep trying.");
                                        break;
                                    //}
                                }
                            } else {
                                c++;
                                response = random.nextInt(4);
                                switch (response) {
                                    case 0:
                                        System.out.println("Very good!");
                                        break;
                                    case 1:
                                        System.out.println("Excellent!");
                                        break;
                                    case 2:
                                        System.out.println("Nice work!");
                                        break;
                                    case 3:
                                        System.out.println("Keep up the good work!");
                                        break;
                                }

                            }

                            results = c / 10;
                            System.out.println(results);
                            if (results < .75) {
                                System.out.println("Please ask your teacher for extra help.");
                            } else {
                                System.out.println("Congratulations, you are ready to go to the next level!");
                            }
                            // Recursively calls main for a reset!
                            work(args);
                        }

                    }
                }
            }
        }
        if (arithmetic == 1) {
            if (level == 1) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10);
                    y = random.nextInt(10);

                    System.out.println("How much is " + x + " plus " + y + "?");
                    z = x + y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }
                        //}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 2) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(100);
                    y = random.nextInt(100);

                    System.out.println("How much is " + x + " plus " + y + "?");
                    z = x + y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;

                        }   //}

                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            }
            else if (level == 3) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(1000);
                    y = random.nextInt(1000);

                    System.out.println("How much is " + x + " plus " + y + "?");
                    z = x + y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }//}
                    }
                    else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 4) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10000);
                    y = random.nextInt(10000);

                    System.out.println("How much is " + x + " plus " + y + "?");
                    z = x + y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                            //}
                        }
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }

                    }

                    results = c / 10;
                    System.out.println(results);
                    if (results < .75) {
                        System.out.println("Please ask your teacher for extra help.");
                    } else {
                        System.out.println("Congratulations, you are ready to go to the next level!");
                    }
                    // Recursively calls main for a reset!
                    work(args);
                }
            }
        } else if (arithmetic == 2) {
            if (level == 1) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10);
                    y = random.nextInt(10);

                    System.out.println("How much is " + x + " times " + y + "?");
                    z = x * y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }
                        //}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");

                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
               work(args);
            } else if (level == 2) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(100);
                    y = random.nextInt(100);

                    System.out.println("How much is " + x + " times " + y + "?");
                    z = x * y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;

                        }   //}

                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 3) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(1000);
                    y = random.nextInt(1000);

                    System.out.println("How much is " + x + " times " + y + "?");
                    z = x * y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }//}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 4) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10000);
                    y = random.nextInt(10000);

                    System.out.println("How much is " + x + " times " + y + "?");
                    z = x * y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                            //}
                        }
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }

                    }

                    results = c / 10;
                    System.out.println(results);
                    if (results < .75) {
                        System.out.println("Please ask your teacher for extra help.");
                    } else {
                        System.out.println("Congratulations, you are ready to go to the next level!");
                    }
                    // Recursively calls main for a reset!
                    work(args);
                }

            }
        } else if (arithmetic == 3) {
            if (level == 1) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10);
                    y = random.nextInt(10);

                    System.out.println("How much is " + x + " minus " + y + "?");
                    z = x - y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }
                        //}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 2) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(100);
                    y = random.nextInt(100);

                    System.out.println("How much is " + x + " minus " + y + "?");
                    z = x - y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;

                        }   //}

                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 3) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(1000);
                    y = random.nextInt(1000);

                    System.out.println("How much is " + x + " minus " + y + "?");
                    z = x - y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }//}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 4) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10000);
                    y = random.nextInt(10000);

                    System.out.println("How much is " + x + " minus " + y + "?");
                    z = x - y;
                    a = sn.nextInt();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                            //}
                        }
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }

                    }

                    results = c / 10;
                    System.out.println(results);
                    if (results < .75) {
                        System.out.println("Please ask your teacher for extra help.");
                    } else {
                        System.out.println("Congratulations, you are ready to go to the next level!");
                    }
                    // Recursively calls main for a reset!
                    work(args);
                }

            }
        } else if (arithmetic == 4) {
            if (level == 1) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10);
                    y = random.nextInt(10);

                    System.out.println("How much is " + x + " divided by " + y + "?");
                    z = x / y;
                    a = sn.nextDouble();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }
                        //}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 2) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(100);
                    y = random.nextInt(100);

                    System.out.println("How much is " + x + " divided by " + y + "?");
                    z = x / y;
                    a = sn.nextDouble();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;

                        }   //}

                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 3) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(1000);
                    y = random.nextInt(1000);

                    System.out.println("How much is " + x + " divided by " + y + "?");
                    z = x / y;
                    a = sn.nextDouble();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                        }//}
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;

                        }
                    }
                }

                results = c / 10;
                System.out.println(results);
                if (results < .75) {
                    System.out.println("Please ask your teacher for extra help.");
                } else {
                    System.out.println("Congratulations, you are ready to go to the next level!");
                }
                // Recursively calls main for a reset!
                work(args);
            } else if (level == 4) {
                for (i = 0; i < 10; i++) {
                    x = random.nextInt(10000);
                    y = random.nextInt(10000);

                    System.out.println("How much is " + x + " divided by " + y + "?");
                    z = x / y;
                    a = sn.nextDouble();
                    if (a != z) {
                        // While(a != z) removed for part 3!
                        //{
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("No. Please try again.");
                                break;
                            case 1:
                                System.out.println("Wrong. Please try again.");
                                break;
                            case 2:
                                System.out.println("Don't give up!");
                                break;
                            case 3:
                                System.out.println("No. Keep trying.");
                                break;
                            //}
                        }
                    } else {
                        c++;
                        response = random.nextInt(4);
                        switch (response) {
                            case 0:
                                System.out.println("Very good!");
                                break;
                            case 1:
                                System.out.println("Excellent!");
                                break;
                            case 2:
                                System.out.println("Nice work!");
                                break;
                            case 3:
                                System.out.println("Keep up the good work!");
                                break;
                        }

                    }

                    results = c / 10;
                    System.out.println(results);
                    if (results < .75) {
                        System.out.println("Please ask your teacher for extra help.");
                    } else {
                        System.out.println("Congratulations, you are ready to go to the next level!");
                    }
                    // Recursively calls main for a reset!
                    work(args);
                }

            }
        }

    }
}