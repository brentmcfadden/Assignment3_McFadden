class Application {

    private static double savingsBalance;

    @org.junit.jupiter.api.Test
    public static void main(String[] args){
        SavingsAccount saver1 = new SavingsAccount();
        SavingsAccount saver2 = new SavingsAccount();
        // used in recalculation of 1 and 2 for new rate
        SavingsAccount saver3 = new SavingsAccount();
        SavingsAccount saver4 = new SavingsAccount();

        System.out.println("Set annual interest rate");
        double annualInterestRate = SavingsAccount.modifyInterestRate();

        System.out.println("Set savingsBalance for Saver1");
        double savingsbalance = 2000.00;
        saver1.setSavings(savingsbalance);
        saver3.setSavings(savingsbalance);
        int i;
        for (i = 0; i < 12; i++) {
            saver1.calculateMonthlyInterest(savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + savingsBalance);
        }
        System.out.println("Set savingsBalance for Saver2");
        savingsbalance = 3000.00;
        saver2.setSavings(savingsbalance);
        saver4.setSavings(savingsbalance);
        for (i = 0; i < 12; i++) {
            saver2.calculateMonthlyInterest(savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + savingsBalance);
        }
        System.out.println("Set new annual interest rate");
        annualInterestRate = SavingsAccount.modifyInterestRate();
        for (i = 0; i < 12; i++) {
            saver3.calculateMonthlyInterest(savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + savingsBalance);
        }
        for (i = 0; i < 12; i++) {
            saver4.calculateMonthlyInterest(savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + savingsBalance);
        }
    }
}


