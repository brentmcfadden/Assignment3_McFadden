import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SavingsAccountTest {

    @Test
    void testMain() {

    }

    @Test
    void testCalculateMonthlyInterest() {
    }

    @Test
    void testSetSavings() {
    }

    @Test
    void testModifyInterestRate() {
    }
}