import java.util.Scanner;

public class SavingsAccount {
    private double savingsBalance;

    public static void main(String[] args){
        Scanner sn = new Scanner(System.in);
        double money;
        double annualInterestRate;
        int i;
        SavingsAccount saver1 = new SavingsAccount();
        SavingsAccount saver2 = new SavingsAccount();
        // used in recalculation of 1 and 2 for new rate
        SavingsAccount saver3 = new SavingsAccount();
        SavingsAccount saver4 = new SavingsAccount();

        System.out.println("Set annual interest rate");
        annualInterestRate = modifyInterestRate();

        System.out.println("Set savingsBalance for Saver1");
        money = sn.nextDouble();
        saver1.setSavings(money);
        saver3.setSavings(money);
        for(i = 0; i< 12; i++) {
            saver1.calculateMonthlyInterest(saver1.savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + saver1.savingsBalance);
        }
        System.out.println("Set savingsBalance for Saver2");
        money = sn.nextDouble();
        saver2.setSavings(money);
        saver4.setSavings(money);
        for(i = 0; i< 12; i++) {
            saver2.calculateMonthlyInterest(saver2.savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + saver2.savingsBalance);
        }
        System.out.println("Set new annual interest rate");
        annualInterestRate = modifyInterestRate();
        for(i = 0; i< 12; i++) {
            saver3.calculateMonthlyInterest(saver1.savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + saver3.savingsBalance);
        }
        for(i = 0; i< 12; i++) {
            saver4.calculateMonthlyInterest(saver2.savingsBalance, annualInterestRate);
            System.out.println("New savings balance equals: " + saver4.savingsBalance);
        }
    }
    public void calculateMonthlyInterest(double savingsBalance, double annualInterestRate){
        this.savingsBalance = savingsBalance + ((savingsBalance * annualInterestRate) / 12);
    }
    public void setSavings(double money) {
        this.savingsBalance = money;
    }
    public static double modifyInterestRate(){
        Scanner sn = new Scanner(System.in);
        return sn.nextDouble();
    }

}